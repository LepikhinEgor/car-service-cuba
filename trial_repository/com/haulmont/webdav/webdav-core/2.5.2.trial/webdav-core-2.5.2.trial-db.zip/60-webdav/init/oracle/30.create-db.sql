
insert into SYS_LOCK_CONFIG (id, create_ts, name, timeout_sec) values (newid(), current_timestamp, 'webdav$WebdavFileDescriptor', 60000) ^

-- <security constraints
insert into SEC_CONSTRAINT
(ID, VERSION, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, CHECK_TYPE, OPERATION_TYPE, CODE, ENTITY_NAME, JOIN_CLAUSE, WHERE_CLAUSE, GROOVY_SCRIPT, FILTER_XML, IS_ACTIVE, GROUP_ID)
values ('ab21e489f9dea60ef465009fffac6ede', 1, current_timestamp, 'admin', current_timestamp, null, null, null, 'memory', 'create', null, 'webdav$WebdavDocumentVersion', null, null, 'import com.haulmont.cuba.core.global.AppBeans
import com.haulmont.webdav.tools.WebdavSecurityTools


WebdavSecurityTools wsec = AppBeans.get(WebdavSecurityTools)
return wsec.isUserPermittedToCreateDocumentByWebdavDocumentVersion({E})
', null, 1, '0fa2b1a51d684d699fbddff348347f93')^

insert into SEC_CONSTRAINT
(ID, VERSION, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, CHECK_TYPE, OPERATION_TYPE, CODE, ENTITY_NAME, JOIN_CLAUSE, WHERE_CLAUSE, GROOVY_SCRIPT, FILTER_XML, IS_ACTIVE, GROUP_ID)
values ('1822eed86dde8616d4858c7d143f32ae', 2, current_timestamp, 'admin', current_timestamp, 'admin', null, null, 'memory', 'read', null, 'webdav$WebdavDocumentVersion', null, null, 'import com.haulmont.cuba.core.global.AppBeans
import com.haulmont.webdav.tools.WebdavSecurityTools


WebdavSecurityTools wsec = AppBeans.get(WebdavSecurityTools)
return wsec.isUserPermittedToReadDocumentByWebdavDocumentVersion({E})
', null, 1, '0fa2b1a51d684d699fbddff348347f93')^

insert into SEC_CONSTRAINT
(ID, VERSION, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, CHECK_TYPE, OPERATION_TYPE, CODE, ENTITY_NAME, JOIN_CLAUSE, WHERE_CLAUSE, GROOVY_SCRIPT, FILTER_XML, IS_ACTIVE, GROUP_ID)
values ('fa95e0e126d16af971d9018d0c73cadc', 2, current_timestamp, 'admin', current_timestamp, 'admin', null, null, 'memory', 'update', null, 'webdav$WebdavDocumentVersion', null, null, 'import com.haulmont.cuba.core.global.AppBeans
import com.haulmont.webdav.tools.WebdavSecurityTools


WebdavSecurityTools wsec = AppBeans.get(WebdavSecurityTools)
return wsec.isUserPermittedToUpdateDocumentByWebdavDocumentVersion({E})
', null, 1, '0fa2b1a51d684d699fbddff348347f93')^

insert into SEC_CONSTRAINT
(ID, VERSION, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, CHECK_TYPE, OPERATION_TYPE, CODE, ENTITY_NAME, JOIN_CLAUSE, WHERE_CLAUSE, GROOVY_SCRIPT, FILTER_XML, IS_ACTIVE, GROUP_ID)
values ('f1e6e1b858258de42aab15523331e27a', 1, current_timestamp, 'admin', current_timestamp, null, null, null, 'memory', 'delete', null, 'webdav$WebdavDocumentVersion', null, null, 'import com.haulmont.cuba.core.global.AppBeans
import com.haulmont.webdav.tools.WebdavSecurityTools


WebdavSecurityTools wsec = AppBeans.get(WebdavSecurityTools)
return wsec.isUserPermittedToDeleteDocumentByWebdavDocumentVersion({E})', null, 1, '0fa2b1a51d684d699fbddff348347f93')^
-- security constraints/>

-- <scheduled tasks
insert into SYS_SCHEDULED_TASK
(ID, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, DEFINED_BY, BEAN_NAME, METHOD_NAME, CLASS_NAME, SCRIPT_NAME, USER_NAME, IS_SINGLETON, IS_ACTIVE, PERIOD_, TIMEOUT, START_DATE, CRON, SCHEDULING_TYPE, TIME_FRAME, START_DELAY, PERMITTED_SERVERS, LOG_START, LOG_FINISH, LAST_START_TIME, LAST_START_SERVER, METHOD_PARAMS, DESCRIPTION)
values ('3b5711e61676271b82e94d98b69e1150', current_timestamp, 'admin', current_timestamp, 'admin', null, null, 'B', 'webdav_WebdavLockExpiredCleaner', 'gcExpiredLocks', null, null, 'admin', null, 1, 28800, null, null, null, 'P', null, null, null, null, null, null, null, '<?xml version="1.0" encoding="UTF-8"?>

<params/>
', 'Task for cleaning expired locks')^

insert into SYS_SCHEDULED_TASK
(ID, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, DEFINED_BY, BEAN_NAME, METHOD_NAME, CLASS_NAME, SCRIPT_NAME, USER_NAME, IS_SINGLETON, IS_ACTIVE, PERIOD_, TIMEOUT, START_DATE, CRON, SCHEDULING_TYPE, TIME_FRAME, START_DELAY, PERMITTED_SERVERS, LOG_START, LOG_FINISH, LAST_START_TIME, LAST_START_SERVER, METHOD_PARAMS, DESCRIPTION)
values ('cb64da3efc59e7ad67c9d4af8b15362d', current_timestamp, 'admin', current_timestamp, 'admin', null, null, 'B', 'webdav_WebdavDocumentVersionsCleaner', 'removeUnreferencedVersions', null, null, 'admin', null, 1, 2592000, null, null, null, 'P', null, null, null, null, null, null, null, '<?xml version="1.0" encoding="UTF-8"?>

<params/>
', 'Task for removing versions with document=null')^
-- scheduled tasks/>